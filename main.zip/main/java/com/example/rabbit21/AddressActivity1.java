package com.example.rabbit21;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class AddressActivity1 extends AppCompatActivity {

    EditText editTextAddress;
    Button buttonPlaceOrder;

    FirebaseFirestore db;

    String productId, productName, userId;
    int quantity;
    double price;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_address1);

        editTextAddress = findViewById(R.id.editTextAddress);
        buttonPlaceOrder = findViewById(R.id.buttonPlaceOrder);

        db = FirebaseFirestore.getInstance();

        // Get data from intent
        productId = getIntent().getStringExtra("productId");
        productName = getIntent().getStringExtra("productName");
        userId = getIntent().getStringExtra("userId");
        quantity = getIntent().getIntExtra("productQty", 1);
        price = Double.parseDouble(getIntent().getStringExtra("productPrice"));

        buttonPlaceOrder.setOnClickListener(v -> {
            String address = editTextAddress.getText().toString().trim();
            if (address.isEmpty()) {
                Toast.makeText(this, "Please enter delivery address", Toast.LENGTH_SHORT).show();
                return;
            }

            placeOrder(address);
        });
    }

    private void placeOrder(String address) {
        Map<String, Object> order = new HashMap<>();
        order.put("productId", productId);
        order.put("productName", productName);
        order.put("quantity", quantity);
        order.put("totalPrice", price * quantity);
        order.put("address", address);
        order.put("userId", userId);
        order.put("status", "Pending");

        db.collection("orders").add(order)
                .addOnSuccessListener(documentReference -> {
                    Toast.makeText(this, "Order Placed Successfully!", Toast.LENGTH_LONG).show();
                    finish(); // Close the activity
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Failed to place order", Toast.LENGTH_SHORT).show();
                });
    }
}
