package com.example.rabbit21;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Button;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.List;

public class CartActivity1 extends AppCompatActivity {

    RecyclerView recyclerViewCart;
    TextView textViewTotal;
    CartAdapter cartAdapter;
    List<CartItem> cartItemList;
    FirebaseFirestore db;
    String userId = "demo_user"; // Replace with FirebaseAuth if needed

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart1);

        recyclerViewCart = findViewById(R.id.recyclerViewCart);
        textViewTotal = findViewById(R.id.textViewTotal);
        Button buttonBuyNow = findViewById(R.id.buttonBuyNow);

        db = FirebaseFirestore.getInstance();
        cartItemList = new ArrayList<>();

        // Setup CartAdapter with both Remove and Buy callbacks
        cartAdapter = new CartAdapter(this, cartItemList,
                total -> textViewTotal.setText("Total: ₹" + total),
                new CartAdapter.OnCartActionListener() {
                    @Override
                    public void onRemoveClicked(String cartId, int position) {
                        removeCartItem(cartId, position);
                    }

                    @Override
                    public void onBuyClicked(CartItem item, int position) {
                        buySingleItem(item, position);
                    }
                });

        recyclerViewCart.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewCart.setAdapter(cartAdapter);

        buttonBuyNow.setOnClickListener(view -> placeOrder());

        loadCartItems();
    }

    private void loadCartItems() {
        db.collection("cart")
                .whereEqualTo("userId", userId)
                .get()
                .addOnSuccessListener(querySnapshot -> {
                    cartItemList.clear();
                    for (QueryDocumentSnapshot doc : querySnapshot) {
                        String productId = doc.getString("productId");
                        int quantity = doc.getLong("quantity").intValue();
                        String cartId = doc.getId();
                        fetchProduct(productId, quantity, cartId);
                    }
                })
                .addOnFailureListener(e -> Toast.makeText(this, "Error loading cart", Toast.LENGTH_SHORT).show());
    }

    private void fetchProduct(String productId, int quantity, String cartId) {
        db.collection("products").document(productId)
                .get()
                .addOnSuccessListener(documentSnapshot -> {
                    Product product = documentSnapshot.toObject(Product.class);
                    if (product != null) {
                        CartItem item = new CartItem(product, quantity, cartId);
                        cartItemList.add(item);
                        cartAdapter.notifyDataSetChanged();
                        cartAdapter.calculateTotal();
                    }
                });
    }

    private void placeOrder() {
        if (cartItemList.isEmpty()) {
            Toast.makeText(this, "Cart is empty", Toast.LENGTH_SHORT).show();
            return;
        }

        int total = 0;
        for (CartItem item : cartItemList) {
            total += item.getProduct().getPrice() * item.getQuantity();
        }

        Order order = new Order(userId, cartItemList, total, System.currentTimeMillis());

        db.collection("orders")
                .add(order)
                .addOnSuccessListener(documentReference -> {
                    clearCart();
                    Toast.makeText(this, "Order placed!", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> Toast.makeText(this, "Order failed", Toast.LENGTH_SHORT).show());
    }

    private void clearCart() {
        for (CartItem item : cartItemList) {
            db.collection("cart").document(item.getCartId()).delete();
        }
        cartItemList.clear();
        cartAdapter.notifyDataSetChanged();
        cartAdapter.calculateTotal();
    }

    private void removeCartItem(String cartId, int position) {
        db.collection("cart").document(cartId).delete()
                .addOnSuccessListener(unused -> {
                    cartItemList.remove(position);
                    cartAdapter.notifyItemRemoved(position);
                    cartAdapter.calculateTotal();
                    Toast.makeText(this, "Item removed from cart", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> Toast.makeText(this, "Failed to remove item", Toast.LENGTH_SHORT).show());
    }

    private void buySingleItem(CartItem item, int position) {
        int total = (int) (item.getProduct().getPrice() * item.getQuantity());
        List<CartItem> singleItemList = new ArrayList<>();
        singleItemList.add(item);

        Order order = new Order(userId, singleItemList, total, System.currentTimeMillis());

        db.collection("orders")
                .add(order)
                .addOnSuccessListener(docRef -> {
                    db.collection("cart").document(item.getCartId()).delete();
                    cartItemList.remove(position);
                    cartAdapter.notifyItemRemoved(position);
                    cartAdapter.calculateTotal();
                    Toast.makeText(this, "Item purchased!", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> Toast.makeText(this, "Purchase failed", Toast.LENGTH_SHORT).show());
    }
}
