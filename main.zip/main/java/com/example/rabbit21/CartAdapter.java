package com.example.rabbit21;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.CartViewHolder> {

    Context context;
    List<CartItem> cartItems;
    OnTotalChangeListener totalChangeListener;
    OnCartActionListener cartActionListener;

    public interface OnTotalChangeListener {
        void onTotalChanged(int total);
    }

    public interface OnCartActionListener {
        void onRemoveClicked(String cartId, int position);
        void onBuyClicked(CartItem item, int position); // for buy action
    }

    public CartAdapter(Context context, List<CartItem> cartItems,
                       OnTotalChangeListener totalChangeListener,
                       OnCartActionListener cartActionListener) {
        this.context = context;
        this.cartItems = cartItems;
        this.totalChangeListener = totalChangeListener;
        this.cartActionListener = cartActionListener;
    }

    @NonNull
    @Override
    public CartViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_cart, parent, false);
        return new CartViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CartViewHolder holder, int position) {
        CartItem item = cartItems.get(position);

        holder.textViewName.setText(item.getProduct().getName());
        holder.textViewQty.setText("Qty: " + item.getQuantity());
        holder.textViewPrice.setText("₹" + (item.getProduct().getPrice() * item.getQuantity()));

        // Remove button logic
        holder.buttonRemove.setOnClickListener(v -> {
            if (cartActionListener != null) {
                cartActionListener.onRemoveClicked(item.getCartId(), holder.getAdapterPosition());
            }
        });

        // Buy button logic
        holder.buttonBuy.setOnClickListener(v -> {
            if (cartActionListener != null) {
                cartActionListener.onBuyClicked(item, holder.getAdapterPosition());
            }
        });
    }

    @Override
    public int getItemCount() {
        return cartItems.size();
    }

    public void calculateTotal() {
        int total = 0;
        for (CartItem item : cartItems) {
            total += item.getProduct().getPrice() * item.getQuantity();
        }
        totalChangeListener.onTotalChanged(total);
    }

    public static class CartViewHolder extends RecyclerView.ViewHolder {
        TextView textViewName, textViewQty, textViewPrice;
        Button buttonRemove, buttonBuy;

        public CartViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewName = itemView.findViewById(R.id.textViewCartName);
            textViewQty = itemView.findViewById(R.id.textViewCartQty);
            textViewPrice = itemView.findViewById(R.id.textViewCartPrice);
            buttonRemove = itemView.findViewById(R.id.buttonRemove);
            buttonBuy = itemView.findViewById(R.id.buttonBuy);
        }
    }
}
