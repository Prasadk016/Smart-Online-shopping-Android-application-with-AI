package com.example.rabbit21;

public class CartItem {
    private Product product;
    private int quantity;
    private String cartId;

    public CartItem(Product product, int quantity, String cartId) {
        this.product = product;
        this.quantity = quantity;
        this.cartId = cartId;
    }

    public Product getProduct() {
        return product;
    }

    public int getQuantity() {
        return quantity;
    }

    public String getCartId() {
        return cartId;
    }
}

