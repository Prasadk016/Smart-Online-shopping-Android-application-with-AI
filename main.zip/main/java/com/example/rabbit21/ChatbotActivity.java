package com.example.rabbit21;


import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.Timestamp;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ChatbotActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private EditText inputMessage;
    private ImageButton sendBtn;
    private MessageAdapter adapter;
    private ArrayList<MessageModel> messageList;

    private FirebaseFirestore db;
    private CollectionReference messageRef, botRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chatbot);

        recyclerView = findViewById(R.id.recyclerView);
        inputMessage = findViewById(R.id.inputMessage);
        sendBtn = findViewById(R.id.sendBtn);

        db = FirebaseFirestore.getInstance();
        messageRef = db.collection("messages");
        botRef = db.collection("bot_responses");

        messageList = new ArrayList<>();
        adapter = new MessageAdapter(this, messageList);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        loadMessages();

        sendBtn.setOnClickListener(v -> {
            String userMsg = inputMessage.getText().toString().trim();
            if (!TextUtils.isEmpty(userMsg)) {
                sendMessage(userMsg);
            }
        });

        // Upload bot responses if needed
        uploadBotResponsesIfNeeded();
    }

    private void loadMessages() {
        messageRef.orderBy("timestamp", Query.Direction.ASCENDING)
                .addSnapshotListener((value, error) -> {
                    if (value != null) {
                        messageList.clear();
                        for (DocumentSnapshot doc : value.getDocuments()) {

                            MessageModel message = doc.toObject(MessageModel.class);
                            messageList.add(message);
                        }
                        adapter.notifyDataSetChanged();
                        recyclerView.scrollToPosition(messageList.size() - 1);
                    }
                });
    }

    private void sendMessage(String text) {
        inputMessage.setText("");

        MessageModel userMsg = new MessageModel(text, "user", Timestamp.now());
        messageRef.add(userMsg);

        getBotResponse(text);
    }

    private void getBotResponse(String userInput) {
        String keyword = userInput.toLowerCase();

        botRef.whereEqualTo("keyword", keyword)
                .get()
                .addOnCompleteListener(task -> {
                    String response = "Sorry, I don't understand.";
                    if (task.isSuccessful()) {
                        QuerySnapshot snapshot = task.getResult();
                        if (!snapshot.isEmpty()) {
                            response = snapshot.getDocuments().get(0).getString("response");
                        }
                    }
                    MessageModel botMsg = new MessageModel(response, "bot", Timestamp.now());
                    messageRef.add(botMsg);
                });
    }

    private void uploadBotResponsesIfNeeded() {
        SharedPreferences prefs = getSharedPreferences("chatbot_prefs", MODE_PRIVATE);
        boolean uploaded = prefs.getBoolean("bot_responses_uploaded", false);

        if (!uploaded) {
            try {
                InputStream is = getAssets().open("bot_responses.json");
                BufferedReader reader = new BufferedReader(new InputStreamReader(is));
                StringBuilder jsonBuilder = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    jsonBuilder.append(line);
                }

                JSONArray jsonArray = new JSONArray(jsonBuilder.toString());

                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject obj = jsonArray.getJSONObject(i);
                    String keyword = obj.getString("keyword").toLowerCase();
                    String response = obj.getString("response");

                    Map<String, Object> data = new HashMap<>();
                    data.put("keyword", keyword);
                    data.put("response", response);

                    botRef.add(data);
                }

                // Mark as uploaded
                prefs.edit().putBoolean("bot_responses_uploaded", true).apply();
                Toast.makeText(this, "Bot responses uploaded!", Toast.LENGTH_SHORT).show();

            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(this, "Upload failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
    }
}
