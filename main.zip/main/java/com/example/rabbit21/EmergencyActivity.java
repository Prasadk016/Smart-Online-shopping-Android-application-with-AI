package com.example.rabbit21;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;

import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;


public class EmergencyActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ProductAdapter productAdapter;
    ArrayList<Product> productList;
    FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emergency);

        // Setup Toolbar
        Toolbar toolbar = findViewById(R.id.toolBar);
        setSupportActionBar(toolbar);

        recyclerView = findViewById(R.id.recyclerViewProducts);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        productList = new ArrayList<>();
        productAdapter = new ProductAdapter(this, productList);
        recyclerView.setAdapter(productAdapter);

        db = FirebaseFirestore.getInstance();
        fetchProducts();


        SharedPreferences prefs = getSharedPreferences("app_prefs", MODE_PRIVATE);
        boolean isUploaded = prefs.getBoolean("products_uploaded", false);

        if (!isUploaded) {
            uploadProductsFromJson();
            prefs.edit().putBoolean("products_uploaded", true).apply();
        }



    }

    private void uploadProductsFromJson() {
        try {
            InputStream is = getAssets().open("products.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();

            String json = new String(buffer, StandardCharsets.UTF_8);

            JSONArray jsonArray = new JSONArray(json);
            FirebaseFirestore db = FirebaseFirestore.getInstance();

            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject obj = jsonArray.getJSONObject(i);

                String id = obj.getString("id");
                String name = obj.getString("name");
                String description = obj.getString("description");
                double price = obj.getDouble("price");
                String imageUrl = obj.getString("imageUrl");

                Map<String, Object> productMap = new HashMap<>();
                productMap.put("name", name);
                productMap.put("description", description);
                productMap.put("price", price);
                productMap.put("imageUrl", imageUrl);

                db.collection("products").document(id).set(productMap)
                        .addOnSuccessListener(aVoid -> {
                            // Optional success log
                        })
                        .addOnFailureListener(e -> {
                            Toast.makeText(this, "Failed to upload: " + name, Toast.LENGTH_SHORT).show();
                        });
            }

            Toast.makeText(this, "Products uploaded successfully", Toast.LENGTH_SHORT).show();

        } catch (IOException | JSONException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error reading products.json", Toast.LENGTH_SHORT).show();
        }
    }


    private void fetchProducts() {
        db.collection("products").get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        QuerySnapshot snapshots = task.getResult();
                        if (snapshots != null) {
                            productList.clear();
                            for (DocumentSnapshot doc : snapshots) {
                                Product product = doc.toObject(Product.class);
                                if (product != null) {
                                    product.setId(doc.getId());
                                    productList.add(product);
                                }
                            }
                            productAdapter.notifyDataSetChanged();
                        }
                    } else {
                        Toast.makeText(EmergencyActivity.this, "Failed to load products.", Toast.LENGTH_SHORT).show();
                    }
                });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.emergency_menu, menu);

        // Set up SearchView
        MenuItem searchItem = menu.findItem(R.id.menu_search);
        SearchView searchView = (SearchView) searchItem.getActionView();
        searchView.setQueryHint("Search products...");

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false; // no action on submit
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filterProducts(newText);
                return true;
            }
        });

        return true;
    }

    private void filterProducts(String query) {
        ArrayList<Product> filteredList = new ArrayList<>();
        for (Product product : productList) {
            if (product.getName().toLowerCase().contains(query.toLowerCase())) {
                filteredList.add(product);
            }
        }
        productAdapter.updateList(filteredList);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.menu_cart) {
            startActivity(new Intent(this, CartActivity1.class));
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
