package com.example.rabbit21;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import com.example.rabbit21.fragments.HomeFragment1;
import com.google.firebase.auth.FirebaseAuth;

public class GroceryActivity extends AppCompatActivity {

    Toolbar toolbar;

    FirebaseAuth auth;

    Fragment homeFragment1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grocery);

        auth = FirebaseAuth.getInstance();

        toolbar = findViewById(R.id.home_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_baseline_lock_24);

        homeFragment1 = new HomeFragment1();
        loadFragment(homeFragment1);
    }

    private void loadFragment(Fragment homeFragment) {

        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.home_container,homeFragment1);
        transaction.commit();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.nav_logout){

            auth.signOut();
            startActivity(new Intent(GroceryActivity.this,LoginActivity.class));
            finish();

        } else
        if (id == R.id.menu_my_cart){

            startActivity(new Intent(GroceryActivity.this,CartActivity.class));
        }

        return true;
    }
}