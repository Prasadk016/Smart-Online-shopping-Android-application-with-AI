package com.example.rabbit21;

import com.google.firebase.Timestamp;

public class MessageModel {
    private String message;
    private String sender;
    private Timestamp timestamp;

    public MessageModel() {} // Required for Firestore

    public MessageModel(String message, String sender, Timestamp timestamp) {
        this.message = message;
        this.sender = sender;
        this.timestamp = timestamp;
    }

    public String getMessage() {
        return message;
    }

    public String getSender() {
        return sender;
    }

    public Timestamp getTimestamp() {
        return timestamp;
    }
}


