package com.example.rabbit21;


import java.util.List;

public class Order {
    private String userId;
    private List<CartItem> items;
    private int totalAmount;
    private long timestamp;

    public Order() {} // Firestore needs this

    public Order(String userId, List<CartItem> items, int totalAmount, long timestamp) {
        this.userId = userId;
        this.items = items;
        this.totalAmount = totalAmount;
        this.timestamp = timestamp;
    }

    public String getUserId() {
        return userId;
    }

    public List<CartItem> getItems() {
        return items;
    }

    public int getTotalAmount() {
        return totalAmount;
    }

    public long getTimestamp() {
        return timestamp;
    }
}
