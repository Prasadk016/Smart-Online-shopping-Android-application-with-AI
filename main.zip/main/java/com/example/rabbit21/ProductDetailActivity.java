package com.example.rabbit21;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.FirebaseFirestore;
import com.squareup.picasso.Picasso;

import java.util.HashMap;
import java.util.Map;

public class ProductDetailActivity extends AppCompatActivity {

    ImageView imageViewProduct, addItem, removeItem;
    TextView textViewName, textViewDesc, textViewPrice, textViewQuantity;
    Button buttonAddToCart, buttonBuyNow;

    FirebaseFirestore db;
    String productId;
    int quantity = 1;
    double pricePerItem = 0.0;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_detail);

        // Initialize views
        imageViewProduct = findViewById(R.id.imageViewProduct);
        textViewName = findViewById(R.id.textViewName);
        textViewDesc = findViewById(R.id.textViewDesc);
        textViewPrice = findViewById(R.id.textViewPrice);
        buttonAddToCart = findViewById(R.id.buttonAddToCart);
        buttonBuyNow = findViewById(R.id.buttonBuyNow);

        addItem = findViewById(R.id.add_item);
        removeItem = findViewById(R.id.remove_item);
        textViewQuantity = findViewById(R.id.quantity);

        db = FirebaseFirestore.getInstance();

        productId = getIntent().getStringExtra("productId");

        if (productId != null) {
            loadProductDetails(productId);
        }

        addItem.setOnClickListener(v -> {
            quantity++;
            textViewQuantity.setText(String.valueOf(quantity));
            updatePrice();
        });

        removeItem.setOnClickListener(v -> {
            if (quantity > 1) {
                quantity--;
                textViewQuantity.setText(String.valueOf(quantity));
                updatePrice();
            }
        });

        buttonAddToCart.setOnClickListener(v -> addToCart());

        buttonBuyNow.setOnClickListener(v -> buyNow());
    }

    private void loadProductDetails(String id) {
        db.collection("products").document(id).get().addOnSuccessListener(documentSnapshot -> {
            if (documentSnapshot.exists()) {
                Product p = documentSnapshot.toObject(Product.class);
                if (p != null) {
                    textViewName.setText(p.getName());
                    textViewDesc.setText(p.getDescription());
                    pricePerItem = p.getPrice();
                    updatePrice();

                    if (p.getImageUrl() != null) {
                        Picasso.get().load(p.getImageUrl()).into(imageViewProduct);
                    }
                }
            }
        });
    }

    private void updatePrice() {
        double totalPrice = quantity * pricePerItem;
        textViewPrice.setText("₹" + totalPrice);
    }

    private void addToCart() {
        Map<String, Object> cartItem = new HashMap<>();
        cartItem.put("productId", productId);
        cartItem.put("quantity", quantity);
        cartItem.put("userId", "demo_user"); // replace with real user ID

        db.collection("cart").add(cartItem)
                .addOnSuccessListener(documentReference -> {
                    Toast.makeText(this, "Added to Cart", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(ProductDetailActivity.this, CartActivity1.class);
                    intent.putExtra("userId", "demo_user");
                    startActivity(intent);
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(this, "Failed to add to cart", Toast.LENGTH_SHORT).show();
                });
    }

    private void buyNow() {
        Intent intent = new Intent(ProductDetailActivity.this, AddressActivity1.class);
        intent.putExtra("productId", productId);
        intent.putExtra("productName", textViewName.getText().toString());
        intent.putExtra("productPrice", String.valueOf(quantity * pricePerItem));
        intent.putExtra("productQty", quantity);
        intent.putExtra("userId", "demo_user");
        startActivity(intent);
    }
}
