package com.example.rabbit21.fragments;

import android.content.Context;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.SetOptions;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.io.IOException;

public class FirestoreUploader {

    private FirebaseFirestore db;
    private Context context;

    public FirestoreUploader(Context context) {
        this.db = FirebaseFirestore.getInstance();
        this.context = context;
    }

    // Method to upload JSON data to Firestore
    public void uploadCategoryData() {
        try {
            // Read JSON file from assets folder
            InputStream is = context.getAssets().open("category_model.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();

            // Convert the bytes to a string
            String json = new String(buffer, "UTF-8");

            // Convert the string to a JSON array
            JSONArray jsonArray = new JSONArray(json);

            // Upload each category document to Firestore
            CollectionReference categoryRef = db.collection("Category");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject categoryObject = jsonArray.getJSONObject(i);
                CategoryModel category = new CategoryModel();
                category.setImg_url(categoryObject.getString("img_url"));
                category.setName(categoryObject.getString("name"));
                category.setType(categoryObject.getString("type"));

                categoryRef.document(category.getName())  // Use the category name as the document ID
                        .set(category, SetOptions.merge())
                        .addOnSuccessListener(aVoid -> Log.d("FirestoreUploader", "Category added"))
                        .addOnFailureListener(e -> Log.e("FirestoreUploader", "Error adding category", e));
            }
        } catch (IOException | org.json.JSONException e) {
            Log.e("FirestoreUploader", "Error reading JSON", e);
        }
    }

    // Method to upload New Products data
    public void uploadNewProductsData() {
        try {
            InputStream is = context.getAssets().open("data.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();

            String json = new String(buffer, "UTF-8");
            JSONArray jsonArray = new JSONArray(json);

            CollectionReference newProductsRef = db.collection("NewProducts");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject productObject = jsonArray.getJSONObject(i);
                NewProductsModel product = new NewProductsModel();
                product.setImg_url(productObject.getString("img_url"));
                product.setDescription(productObject.getString("description"));
                product.setName(productObject.getString("name"));
                product.setRating(productObject.getString("rating"));
                product.setPrice(productObject.getInt("price"));

                newProductsRef.document(product.getName())  // Use the product name as the document ID
                        .set(product, SetOptions.merge())
                        .addOnSuccessListener(aVoid -> Log.d("FirestoreUploader", "Product added"))
                        .addOnFailureListener(e -> Log.e("FirestoreUploader", "Error adding product", e));
            }
        } catch (IOException | org.json.JSONException e) {
            Log.e("FirestoreUploader", "Error reading JSON", e);
        }
    }

    // Method to upload Popular Products data
    public void uploadPopularProductsData() {
        try {
            InputStream is = context.getAssets().open("popular_products_model.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();

            String json = new String(buffer, "UTF-8");
            JSONArray jsonArray = new JSONArray(json);

            CollectionReference popularProductsRef = db.collection("AllProducts");
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject productObject = jsonArray.getJSONObject(i);
                PopularProductsModel popularProduct = new PopularProductsModel();
                popularProduct.setImg_url(productObject.getString("img_url"));
                popularProduct.setDescription(productObject.getString("description"));
                popularProduct.setName(productObject.getString("name"));
                popularProduct.setRating(productObject.getString("rating"));
                popularProduct.setPrice(productObject.getInt("price"));

                popularProductsRef.document(popularProduct.getName())  // Use the product name as the document ID
                        .set(popularProduct, SetOptions.merge())
                        .addOnSuccessListener(aVoid -> Log.d("FirestoreUploader", "Popular Product added"))
                        .addOnFailureListener(e -> Log.e("FirestoreUploader", "Error adding product", e));
            }
        } catch (IOException | org.json.JSONException e) {
            Log.e("FirestoreUploader", "Error reading JSON", e);
        }
    }
}

