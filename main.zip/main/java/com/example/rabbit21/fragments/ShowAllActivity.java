package com.example.rabbit21.fragments;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.res.AssetManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.example.rabbit21.R;
import com.google.firebase.crashlytics.buildtools.reloc.com.google.common.reflect.TypeToken;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class ShowAllActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ShowAllAdapter showAllAdapter;
    List<ShowAllModel> showAllModelList;
    Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_all);

        toolbar = findViewById(R.id.show_all_toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        toolbar.setNavigationOnClickListener(v -> finish());

        recyclerView = findViewById(R.id.show_all_rec);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));

        showAllModelList = new ArrayList<>();
        showAllAdapter = new ShowAllAdapter(this, showAllModelList);
        recyclerView.setAdapter(showAllAdapter);

        String type = getIntent().getStringExtra("type");

        // Try to load from Firebase Realtime Database
        loadFromFirebase(type);
    }

    private void loadFromFirebase(String type) {
        FirebaseDatabase.getInstance().getReference("ShowAll")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        showAllModelList.clear();
                        for (DataSnapshot data : snapshot.getChildren()) {
                            ShowAllModel model = data.getValue(ShowAllModel.class);
                            if (type == null || type.isEmpty() || model.getType().equalsIgnoreCase(type)) {
                                showAllModelList.add(model);
                            }
                        }
                        showAllAdapter.notifyDataSetChanged();

                        // If list is still empty, fallback to JSON
                        if (showAllModelList.isEmpty()) {
                            loadFromJson(type);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
                        Log.e("FirebaseError", error.getMessage());
                        loadFromJson(type); // fallback to JSON on error
                    }
                });
    }

    private void loadFromJson(String type) {
        try {
            AssetManager assetManager = getAssets();
            InputStream inputStream = assetManager.open("show_all.json");

            Gson gson = new Gson();
            Type listType = new TypeToken<List<ShowAllModel>>() {}.getType();
            List<ShowAllModel> allItems = gson.fromJson(new InputStreamReader(inputStream), listType);

            for (ShowAllModel model : allItems) {
                if (type == null || type.isEmpty() || model.getType().equalsIgnoreCase(type)) {
                    showAllModelList.add(model);
                }
            }

            showAllAdapter.notifyDataSetChanged();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
